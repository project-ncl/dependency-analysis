#!/bin/bash
set -xe
 
echo Using following DA server:
grep daServer config.json
 
da=`pwd`/da-cli.py
 
if $da list whitelist-products | grep "EAP:7.0.1 "; then
        $da delete whitelist-product EAP:7.0.1
fi
 
$da add whitelist-product EAP:7.0.1 SUPPORTED
 
if ! $da list whitelist-products | grep "EAP:7.0.1 SUPPORTED"; then
        echo "FAILed to add product"
        exit 1
fi
 
$da add white foo.bar:whitelisted:1.0.0 EAP:7.0.1
 
if ! $da list white EAP:7.0.1 | grep "foo.bar:whitelisted:1.0.0" ; then
        echo "FAILed to add artifact to product"
        exit 1
fi
 
if $da fill-gav org.jboss.bom:eap-runtime-artifacts:7.0.1.GA EAP:7.0.1 | grep "504"; then
        for i in 1 2 3 4 5; do
                echo "Got 504 timeout, waiting a few seconds for finish (try $i)"
                sleep 10s
                count=`$da list white EAP:7.0.1 | wc -l`
                if [ $count -gt 430 ]; then
                        break;
                fi
        done
fi
 
count=`$da list white EAP:7.0.1 | wc -l`
if [ $count -lt 430 ]; then
        echo "FAILed to fill artifacts to product"
        exit 1
fi
 
if ! $da list whitelist-products | grep "EAP:7.0.2 "; then
        $da add whitelist-product EAP:7.0.2 SUPPORTED
fi
 
count=`$da list white EAP:7.0.2 | wc -l`
 
if [ $count -lt 430 ]; then
        if $da fill-gav org.jboss.bom:eap-runtime-artifacts:7.0.2.GA EAP:7.0.2 | grep "504"; then
                for i in 1 2 3 4 5; do
                        echo "Got 504 timeout, waiting a few seconds for finish (try $i)"
                        sleep 10s
                        count=`$da list white EAP:7.0.2 | wc -l`
                        if [ $count -gt 430 ]; then
                                break;
                        fi
                done
        fi
        count=`$da list white EAP:7.0.2 | wc -l`
        if [ $count -lt 430 ]; then
                echo "FAILed to fill artifacts to product"
                exit 1
        fi
fi
 
if $da list black | grep io.swagger:swagger-jaxrs:1.5.4; then
        $da delete black io.swagger:swagger-jaxrs:1.5.4
        if $da list black | grep io.swagger:swagger-jaxrs:1.5.4; then
                echo "FAILed to delete artifacts from blacklist"
                exit 1
        fi
fi
 
$da add black io.swagger:swagger-jaxrs:1.5.4
 
if ! $da list black | grep io.swagger:swagger-jaxrs:1.5.4; then
        echo "FAILed to add artifacts to blacklist"
        exit 1
fi
 
echo test case PASSed
